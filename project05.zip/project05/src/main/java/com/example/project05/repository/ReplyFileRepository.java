package com.example.project05.repository;



import org.springframework.data.jpa.repository.JpaRepository;

import com.example.project05.model.reply.ReplyFile;

public interface ReplyFileRepository extends JpaRepository<ReplyFile, Long>{


}
