package com.example.project05;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Project05Application {

	public static void main(String[] args) {
		SpringApplication.run(Project05Application.class, args);
	}

}
