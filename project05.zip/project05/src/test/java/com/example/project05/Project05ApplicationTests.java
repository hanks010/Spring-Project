package com.example.project05;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Project05ApplicationTests {

	@Test
	void contextLoads() {
	}

}
